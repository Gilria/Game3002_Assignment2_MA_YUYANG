using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plunger : MonoBehaviour
{
    public float currentPower;
    public float maxPower;
    public float minPower;
    public float powerGrownthSpeed;
    List<Rigidbody> ballList;

    private Transform kicker;
    private Vector3 kickerPos;
    private Vector3 kickerScale;
    


    void Start()
    {
        kicker = transform.Find("Kicker");
        kickerPos = kicker.localPosition;
        kickerScale = kicker.localScale;
        ballList = new List<Rigidbody>();      
    }

    // Update is called once per frame
    void Update()
    {
        
        if (ballList != null&&ballList.Count > 0)
        {
            if (Input.GetKey(KeyCode.Space))
            {
                float _p = (currentPower - minPower) / (maxPower - minPower);

                currentPower = Mathf.Clamp(currentPower + powerGrownthSpeed * Time.deltaTime, minPower, maxPower);
                kicker.localScale = new Vector3(kickerScale.x, kickerScale.y * (1 - _p), kickerScale.z);
                kicker.localPosition = kickerPos + Vector3.back * _p;
            }

            if (Input.GetKeyUp(KeyCode.Space))
            {
                foreach(Rigidbody r in ballList)
                {
                    r.AddForce(currentPower * Vector3.forward);
                }
                kicker.localScale = kickerScale;
                kicker.localPosition = kickerPos;
                currentPower = minPower;

            }

            
        }
    }


    
    private void OnTriggerEnter(Collider other)
    {
       
        if (other.gameObject.CompareTag("Ball"))
        {
            ballList.Add(other.gameObject.GetComponent<Rigidbody>());
            Debug.Log(ballList.Count);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        ballList.Remove(other.gameObject.GetComponent<Rigidbody>());
        currentPower = 0f;
    }
}
