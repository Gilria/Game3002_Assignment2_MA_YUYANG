using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flipper : MonoBehaviour
{
    public bool left;
    public float flipAngle;
    public float flipSpeed;
    public int dotNum;
    public float blinkRant;
    public float addSpeedRant;
    public float maxSpeed;
    public GameObject gameManager;

    private int mouseKey;
    private Quaternion upRotation;
    private Quaternion downRotation;
    private Quaternion aimRotation;
    private Quaternion prevRotation;
    private Vector3[] prevDotPos;
    private Transform[] dotTf;
    private Vector3 AddSpeedPos;


    private void Start()
    {
        mouseKey = left ? 0 : 1;
        AddSpeedPos = transform.Find("AddSpeedPos").position;

        downRotation = aimRotation = prevRotation = transform.localRotation;
        upRotation = Quaternion.Euler(upRotation.eulerAngles + Vector3.up * flipAngle);
        prevDotPos = new Vector3[dotNum];
        dotTf = new Transform[dotNum];
        for (int i = 0; i < dotNum; i++)
        {
            dotTf[i] = transform.Find("Dot" + (i + 1).ToString());
            prevDotPos[i] = dotTf[i].position;
        }
    }

    void Update()
    {
        if (Time.timeScale == 0)
        {
            transform.localRotation = downRotation;
            return;
        }

        if (Input.GetMouseButton(mouseKey))
        {
            aimRotation = upRotation;
        }
        else
        {
            aimRotation = downRotation;
        }

        transform.localRotation = Quaternion.RotateTowards(transform.localRotation, aimRotation, flipSpeed);

        if (transform.localRotation != prevRotation)
        {
            if (aimRotation == upRotation)
            {
                RayFlip();
            }

        }

        prevRotation = transform.localRotation;
        for (int i = 0; i < dotNum; i++)
        {
            prevDotPos[i] = dotTf[i].position;
        }

    }


    void RayFlip()
    {
        for (int i = 0; i < dotNum; i++)
        {
            RaycastHit[] hits = Physics.RaycastAll(prevDotPos[i], dotTf[i].position - prevDotPos[i], Vector3.Distance(prevDotPos[i], dotTf[i].position));
            for (int j = 0; j < hits.Length; j++)
            {
                if (hits[j].transform.CompareTag("Ball"))
                {
                    Rigidbody rig = hits[j].rigidbody;
                    rig.velocity = (hits[j].transform.position - AddSpeedPos).normalized;
                    rig.velocity *= Mathf.Abs(hits[j].transform.position.x - transform.position.x) * addSpeedRant;
                    rig.velocity -= rig.velocity.y * Vector3.up;
                    rig.velocity = Vector3.ClampMagnitude(rig.velocity, maxSpeed);
                    hits[j].transform.GetComponent<Ball>().BlinkTo(hits[j].transform.position + rig.velocity * blinkRant);
                    gameManager.GetComponent<GameManager>().score += 20;
                }
            }
        }
    }








}

   