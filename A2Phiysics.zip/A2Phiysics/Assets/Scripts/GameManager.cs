using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public GameObject ballPrefab;
    public Vector3 createPosition;
    public int life = 4;
    public Text scoreText;
    public Text lifeText;
    public bool destroyBall = false;
    public GameObject pannel;
    


    private GameObject createBall;
    private Rigidbody rig;
    

    public int score;
    
    void Start()
    {
        CreateBall();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (destroyBall == true && life > 0)
        {
            CreateBall();
            destroyBall = false;
        }
        lifeText.text = ((int)life).ToString();
        scoreText.text = ((int)score).ToString();

        if (life == 0)
        {
            pannel.SetActive(true);
        }
    }

    public void CreateBall()
    {
        createBall = (GameObject)Instantiate(ballPrefab, createPosition, transform.rotation);
        
    }

}
