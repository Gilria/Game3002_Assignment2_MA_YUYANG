using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NormalPlunger : MonoBehaviour
{
    public float power;
    List<Rigidbody> ballList;

    private void Start()
    {
        ballList = new List<Rigidbody>();
    }

    private void Update()
    {
        foreach(Rigidbody r in ballList)
        {
            r.AddForce(power * Vector3.forward);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Ball"))
        {
            ballList.Add(other.gameObject.GetComponent<Rigidbody>());
        }
    }

    private void OnTriggerExit(Collider other)
    {
        ballList.Remove(other.gameObject.GetComponent<Rigidbody>());
    }
}
