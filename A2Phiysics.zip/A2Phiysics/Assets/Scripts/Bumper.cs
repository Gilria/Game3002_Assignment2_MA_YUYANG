using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bumper : MonoBehaviour
{
    public float outSpeed;
    public float randomRant;
    public float jumpHeight;
    public float jumpRant;
    public GameObject gameManager;


    private Vector3 upPosition;
    private Vector3 downPosition;


    private void Start()
    {
        upPosition = transform.position;
        downPosition = upPosition + Vector3.down * jumpHeight;
    }

    private void Update()
    {
        transform.localPosition = Vector3.Lerp(transform.localPosition, upPosition, jumpRant);
    }



    void OnCollisionExit(Collision _c)
    {
        
        transform.localPosition = downPosition;
       
       
        Rigidbody rig = _c.gameObject.GetComponent<Rigidbody>();
        rig.velocity = (rig.velocity + Random.insideUnitSphere * randomRant).normalized * outSpeed;
        gameManager.GetComponent<GameManager>().score += 30;
        
    }




}
