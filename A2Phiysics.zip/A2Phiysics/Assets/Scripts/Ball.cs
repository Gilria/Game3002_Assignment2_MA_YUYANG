using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public Vector3 prevPos;


    

    void Start()
    {
        Physics.gravity = new Vector3(0, -5, -30);
        prevPos = transform.position;
        

    }


    


    


    public void BlinkTo(Vector3 _pos)
    {
        prevPos = transform.position = _pos;
    }
}
