using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyPlace : MonoBehaviour
{
    public GameObject gameManager;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Ball"))
        {

            Destroy(other.gameObject);
            gameManager.GetComponent<GameManager>().life--;
            gameManager.GetComponent<GameManager>().destroyBall = true;
        }
    }


   

    //private void OnTriggerEnter(Collision collision)
    //{
    //    Debug.Log("aaaaaaa");
    //    if (collision.gameObject.CompareTag("Ball"))
    //    {

    //        Destroy(ballPrefab);
    //        gameManager.GetComponent<GameManager>().life--;
    //        gameManager.GetComponent<GameManager>().destroyBall = true;
    //    }
    //}
}
